#!/bin/sh

wget -q -O /tmp/oscam.srvid2 http://myupdater.dyndns-ip.com/oscam.srvid2 2>/dev/null

cp /tmp/oscam.srvid2 /var/keys/oscam_sci0/

echo "Restart SoftCam.."
echo ""
/var/bin/softcam restart
echo ""

echo "Pomyślnie zaktualizowano oscam.srvid2" 

rm -rf /tmp/oscam.srvid2

exit 0
