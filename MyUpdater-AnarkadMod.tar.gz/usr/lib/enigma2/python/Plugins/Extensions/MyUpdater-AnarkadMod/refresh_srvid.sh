#!/bin/sh

wget -q -O /tmp/srvid_bh.cfg http://myupdater.dyndns-ip.com/srvid_bh.cfg 2>/dev/null
wget -q -O /tmp/srvid_graterlia.cfg http://myupdater.dyndns-ip.com/srvid_graterlia.cfg 2>/dev/null
wget -q -O /tmp/srvid_nbox.cfg http://myupdater.dyndns-ip.com/srvid_nbox.cfg 2>/dev/null
wget -q -O /tmp/srvid_openpli.cfg http://myupdater.dyndns-ip.com/srvid_openpli.cfg 2>/dev/null
wget -q -O /tmp/srvid_openatv.cfg http://myupdater.dyndns-ip.com/srvid_openatv.cfg 2>/dev/null
wget -q -O /tmp/srvid_openspa.cfg http://myupdater.dyndns-ip.com/srvid_openspa.cfg 2>/dev/null
wget -q -O /tmp/srvid_vti.cfg http://myupdater.dyndns-ip.com/srvid_vti.cfg 2>/dev/null

cp /tmp/srvid_bh.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_graterlia.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_nbox.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_openpli.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_openatv.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_openspa.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
cp /tmp/srvid_vti.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/
		
echo "Odswiezenie daty srvid zakonczono pomyslnie..." 

rm -rf /tmp/srvid_bh.cfg
rm -rf /tmp/srvid_graterlia.cfg
rm -rf /tmp/srvid_nbox.cfg
rm -rf /tmp/srvid_openpli.cfg
rm -rf /tmp/srvid_openatv.cfg
rm -rf /tmp/srvid_openspa.cfg
rm -rf /tmp/srvid_vti.cfg


exit 0
