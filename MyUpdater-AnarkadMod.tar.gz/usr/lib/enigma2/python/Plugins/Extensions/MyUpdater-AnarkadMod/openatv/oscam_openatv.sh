#!/bin/sh

oscam=/usr/bin/
script=/etc/

echo "Stop SoftCam"

echo ""
killall -9 oscam
echo "Kopia zapasowa aktualnej wersji oscam jako oscam-prev"
cp $oscam/oscam $oscam/oscam-prev
echo "Kopia zapasowa skryptu jako oscam.emu-prev"
cp $script/oscam.emu $script/oscam.emu-prev
echo ""

echo "Search new version oscam"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-tuxbox-oe2.0&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 125 "archives" | grep "mips-tuxbox-oe2.0-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-mips-tuxbox-oe2.0-webif-Distribution.tar.gz&directory=1.20_TRUNK/mips-tuxbox-oe2.0&'
echo "Download oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
echo "Unpack tar.gz"
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Copy oscam_$version to /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam
echo "Remove temp file"
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
	dest="/etc/oscam.emu"
	echo -e "emuname = OSCam" > $dest 
	echo -e "binname = oscam" >> $dest
	echo -e "startcam = /usr/bin/oscam -b -r 2 -c /usr/keys/oscam_atv" >> $dest
	echo -e "stopcam = killall -9 oscam 2>/dev/null" >> $dest
	chmod 755 $dest
sleep 1
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo " Start SoftCam "
/usr/bin/oscam -b -r 2 -c /usr/keys/oscam_atv
echo "The End"
