#!/bin/sh

oscam=/usr/bin/
script=/etc/

echo "Stop SoftCam"
killall -9 oscam

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam
echo "Przywracanie skryptu z oscam.emu-prev"
cp $script/oscam.emu-prev $script/oscam.emu

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/usr/bin/oscam -b -r 2 -c /usr/keys/oscam_atv
echo "The End"
