#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/openspa_configi.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/configi.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/openspa_oscamy.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscamy.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_openspa_1.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_openspa.cfg

echo "Konfiguracja zakonczona pomyslnie..." 

exit 0
