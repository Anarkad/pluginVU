#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/CNFIX.zip

cd /tmp/
wget https://github.com/Anarkad/pluginVU/raw/master/oscam/CNFIX.zip -q -O /tmp/CNFIX.zip
FILE=/tmp/CNFIX.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "FIX został pobrany.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/CNFIX.zip -d /tmp/
        cd /tmp/CNFIX
        				rm -f /etc/tuxbox/config/oscam.conf
						rm -f /etc/tuxbox/config/oscam.dvbapi
						rm -f /etc/tuxbox/config/oscam.provid
						rm -f /etc/tuxbox/config/oscam.server
                        rm -f /etc/tuxbox/config/oscam.services
                        rm -f /etc/tuxbox/config/oscam.srvid
                        rm -f /etc/tuxbox/config/oscam.srvid2
                        rm -f /etc/tuxbox/config/oscam.user
                        
            mv /tmp/CNFIX/* /etc/tuxbox/config/
			cd / && rm -rf /tmp/CNFIX
            rm -rf /tmp/CNFIX.zip
            echo ""
            echo "Wgrywanie FIXU zakończono pomyślnie..."
			echo ""
			echo "Wprowadz ponownie login i haslo do serweru oscam!!!"
			echo ""
			echo "Restrat SoftCam"
			echo ""
			/etc/init.d/current_cam.sh restart
   fi
else
    echo ""
    echo "Błąd! brak pliku FIX na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi
