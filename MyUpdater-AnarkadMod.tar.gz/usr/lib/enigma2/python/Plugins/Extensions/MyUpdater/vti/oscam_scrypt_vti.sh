#!/bin/sh

echo "Szukam nowego OSCama"

	wget -q -O /tmp/oscam.info https://raw.githubusercontent.com/Anarkad/pluginVU/master/oscam/oscam.info 2>/dev/null
    version=$(cat /tmp/oscam.info | cut -d- -f2)
	echo "Pobieranie oscam_$version"	
    wget -q -O /tmp/oscam https://github.com/Anarkad/pluginVU/raw/master/oscam/oscam-mipsel 2>/dev/null	
	echo "Kopiowanie oscam_$version do /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam-j_$version
	chmod 755 /usr/bin/oscam-j_$version
	rm /tmp/oscam.info 
	rm /tmp/oscam 
	
	
	dest="/usr/script/oscam-j-"$version"_cam.sh"
echo "Do it file "$dest
	echo -e "#!/bin/sh" > $dest
	echo -e "" >> $dest
	echo -e "CAMNAME=\0042OScam $version by Jej@n\0042" >> $dest 
	echo -e "" >> $dest
	echo -e "case \0042\00441\0042 in" >> $dest
	echo -e "    start)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        /usr/bin/oscam-j_$version -b -r 2 -c /etc/tuxbox/config" >> $dest
	echo -e "        touch /tmp/.emu.info" >> $dest
	echo -e "        echo \0044CAMNAME > /tmp/.emu.info" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    stop)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        killall -9 oscam-j_$version 2>/dev/null" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    restart)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        sleep 2" >> $dest
	echo -e "        \00440 start" >> $dest
	echo -e "        exit" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    *)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        exit 0" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "esac" >> $dest
	echo -e "exit 0 " >> $dest
	chmod 755 $dest
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo "The End"
