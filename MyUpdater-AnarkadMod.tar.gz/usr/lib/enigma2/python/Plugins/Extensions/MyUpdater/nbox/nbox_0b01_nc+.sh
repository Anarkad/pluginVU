#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/nbox_0b01_nc+.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/nbox_0b01_nc+.zip -q -O /tmp/nbox_0b01_nc+.zip
FILE=/tmp/nbox_0b01_nc+.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Config został pobrany.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/nbox_0b01_nc+.zip -d /tmp/
        cd /tmp/nbox_0b01_nc+
        if [ -f oscam.conf ]; then
			rm -fR /var/keys/oscam_sci0/*
            mkdir -p /var/keys/oscam_sci0 && mv /tmp/nbox_0b01_nc+/* /var/keys/oscam_sci0/
			cd / && rm -rf /tmp/nbox_0b01_nc+
            rm -rf /tmp/nbox_0b01_nc+.zip
            echo ""
            echo "Wgrywanie nowego configu zakończono pomyślnie..."
			echo ""
			echo "Restrat SoftCam"
			echo ""
			/var/bin/softcam restart
		else
		    echo ""
            echo "Błąd! brak pełnego configu! Spróbuj ponownie później..."
			echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku config na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi