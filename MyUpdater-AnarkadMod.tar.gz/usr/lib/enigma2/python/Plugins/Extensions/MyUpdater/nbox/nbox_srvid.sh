#!/bin/sh

wget -q -O /tmp/oscam.srvid http://myupdater.dyndns-ip.com/oscam.srvid 2>/dev/null

cp /tmp/oscam.srvid /var/keys/oscam_sci0/

echo "Restart SoftCam.."
echo ""
/var/bin/softcam restart
echo ""

echo "Pomyślnie zaktualizowano oscam.srvid" 

rm -rf /tmp/oscam.srvid

exit 0
