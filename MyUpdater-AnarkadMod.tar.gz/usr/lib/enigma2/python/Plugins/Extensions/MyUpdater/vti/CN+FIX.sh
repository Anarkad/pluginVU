#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/CN+ FIX.zip

cd /tmp/
wget https://github.com/Anarkad/pluginVU/raw/master/oscam/CN+ FIX.zip -q -O /tmp/CN+ FIX.zip
FILE=/tmp/CN+ FIX.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "FIX został pobrany.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/CN+ FIX.zip -d /tmp/
        cd /tmp/CN+ FIX
        				rm -f /etc/tuxbox/config/oscam.conf
						rm -f /etc/tuxbox/config/oscam.dvbapi
						rm -f /etc/tuxbox/config/oscam.provid
						rm -f /etc/tuxbox/config/oscam.server
                        rm -f /etc/tuxbox/config/oscam.services
                        rm -f /etc/tuxbox/config/oscam.srvid
                        rm -f /etc/tuxbox/config/oscam.srvid2
                        rm -f /etc/tuxbox/config/oscam.user
                        
            mv /tmp/CN+ FIX/* /etc/tuxbox/config/
			cd / && rm -rf /tmp/CN+ FIX
            rm -rf /tmp/CN+ FIX.zip
            echo ""
            echo "Wgrywanie FIXU zakończono pomyślnie..."
			echo ""
			echo "Wprowadz ponownie login i haslo do serweru oscam!!!"
			echo ""
			echo "Restrat SoftCam"
			echo ""
			/etc/init.d/current_cam.sh restart
   fi
else
    echo ""
    echo "Błąd! brak pliku FIX na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi
