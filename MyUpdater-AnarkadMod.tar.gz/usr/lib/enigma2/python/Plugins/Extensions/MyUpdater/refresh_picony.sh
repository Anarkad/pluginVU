#!/bin/sh

wget -q -O /tmp/picony.cfg https://raw.githubusercontent.com/Anarkad/pluginVU/master/picony.cfg 2>/dev/null


cp /tmp/picony.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/

		
echo "Odświeżenie daty zakończono pomyślnie..." 


rm -rf /tmp/picony.cfg


exit 0
