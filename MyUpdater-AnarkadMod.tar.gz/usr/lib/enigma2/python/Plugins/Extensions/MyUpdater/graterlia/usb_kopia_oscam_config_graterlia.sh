#!/bin/sh

echo "Tworzenie kopii zapasowej configów oscama, czekaj.."
echo ""

mkdir -p /media/usb/
sleep 1
tar -czf /media/usb/oscam_graterlia_config_kopia.tar.gz /etc/oscam 2>/dev/null

if test -f /media/usb/oscam_graterlia_config_kopia.tar.gz
then

echo "Kopia została utworzona pomyślnie.."
echo ""
sleep 1
echo "Lokalizacja pliku to: /media/usb/oscam_graterlia_config_kopia.tar.gz"
echo ""


else

echo "Wystapił nieoczekiwany błąd - Kopia nie została utworzona.."
echo ""

fi


exit 0
