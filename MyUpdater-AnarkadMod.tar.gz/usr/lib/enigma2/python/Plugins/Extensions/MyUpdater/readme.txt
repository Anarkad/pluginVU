Wtyczka (Plugin) My Updater powstala na bazie pluginu
Menu Fantastic Plugin 0.1.2 by gutemine

Scrypty wykorzystane w tym pluginie nie sa 
wszystkie mojego autorstwa, ale jest ich wiele!
Podziekowania nalezy sie kolegom:
@gasparello
@Vela
@mosz_nowy

Zabraniam wykorzystywania wtyczki w celach komercyjnych!!!
Zabraniam uzywania My Updater przez pay servery!!!

Sancho 2017

Mod bY Vela DVHK User 21.02.2017

[Poprawki w kodzie pythona]

