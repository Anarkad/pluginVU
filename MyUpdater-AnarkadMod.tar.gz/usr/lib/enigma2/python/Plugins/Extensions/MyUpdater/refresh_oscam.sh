#!/bin/sh

wget -q -O /tmp/config_image_vti.cfg https://raw.githubusercontent.com/Anarkad/pluginVU/master/config_image_vti.cfg 2>/dev/null


cp /tmp/config_image_vti.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/

		
echo "Odświeżenie daty zakończono pomyślnie..." 


rm -rf /tmp/config_image_vti.cfg


exit 0
