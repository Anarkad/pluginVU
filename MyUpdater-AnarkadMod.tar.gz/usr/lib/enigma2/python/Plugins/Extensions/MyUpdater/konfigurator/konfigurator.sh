#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/configi.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/configi.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscamy.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscamy.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_bh.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_bh.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_openpli.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_openpli.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_openatv.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_openatv.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_openspa.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_openspa.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_vti.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_vti.cfg


echo "Konfiguracja zakonczona pomyslnie..." 

exit 0
