#!/bin/sh

echo "Tworzenie kopii zapasowej configów oscama, czekaj.."
echo ""

mkdir -p /media/hdd/
sleep 1
tar -czf /media/hdd/oscam_nbox_config_kopia.tar.gz /var/keys/oscam_sci0 2>/dev/null

if test -f /media/hdd/oscam_nbox_config_kopia.tar.gz
then

echo "Kopia została utworzona pomyślnie.."
echo ""
sleep 1
echo "Lokalizacja pliku to: /media/hdd/oscam_nbox_config_kopia.tar.gz"
echo ""


else

echo "Wystapił nieoczekiwany błąd - Kopia nie została utworzona.."
echo ""

fi


exit 0
