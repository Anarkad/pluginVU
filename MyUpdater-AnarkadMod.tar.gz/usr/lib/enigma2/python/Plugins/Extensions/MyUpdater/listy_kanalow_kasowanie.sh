#!/bin/sh

rm -f /etc/enigma2/blacklist &
rm -f /etc/enigma2/whitelist &
rm -f /etc/enigma2/bouquets.* &
rm -f /etc/enigma2/lamedb &
rm -f /etc/enigma2/userbouquet.* &

wget -q -O /dev/null http://127.0.0.1/web/servicelistreload?mode=0 2>/dev/null &

exit 0
