#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/listy_konfigurator.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/main.cfg

echo "Konfiguracja zakończona pomyślnie..."
echo ""

echo "Restartuje GUI"

sleep 2
killall -9 enigma2 2>/dev/null
echo ""

exit 0
