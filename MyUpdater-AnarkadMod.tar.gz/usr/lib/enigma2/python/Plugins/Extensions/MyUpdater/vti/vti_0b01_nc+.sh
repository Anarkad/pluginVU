#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/0b01_nc+.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/0b01_nc+.zip -q -O /tmp/0b01_nc+.zip
FILE=/tmp/0b01_nc+.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Config został pobrany.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/0b01_nc+.zip -d /tmp/
        cd /tmp/0b01_nc+
        if [ -f oscam.conf ]; then
			rm -fR /etc/tuxbox/config/*
            mkdir -p /etc/tuxbox/config && mv /tmp/0b01_nc+/* /etc/tuxbox/config/
			cd / && rm -rf /tmp/0b01_nc+
            rm -rf /tmp/0b01_nc+.zip
            echo ""
            echo "Wgrywanie nowego configu zakończono pomyślnie..."
			echo ""
			echo "Restrat SoftCam"
			echo ""
			/etc/init.d/current_cam.sh restart
		else
		    echo ""
            echo "Błąd! brak pełnego configu! Spróbuj ponownie później..."
			echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku config na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi