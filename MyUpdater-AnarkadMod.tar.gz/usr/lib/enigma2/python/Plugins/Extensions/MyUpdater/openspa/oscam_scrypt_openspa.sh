#!/bin/sh

oscam=/usr/bin
script=/usr/script

echo "Szukam nowego OSCama"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-tuxbox-oe2.0&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 125 "archives" | grep "mips-tuxbox-oe2.0-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-mips-tuxbox-oe2.0-webif-Distribution.tar.gz&directory=1.20_TRUNK/mips-tuxbox-oe2.0&'
echo "Pobieranie oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Kopiowanie oscam_$version do /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam_$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
dest="/usr/script/Oscam_$version.sh"
echo "Tworzenie Scryptu "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAMD_ID=1796" >> $dest
echo -e "CAMD_NAME=\0042OSCam r$version\0042" >> $dest
echo -e "" >> $dest
echo -e "INFOFILE_A=ecm.info" >> $dest
echo -e "INFOFILE_B=/tmp/.oscam" >> $dest
echo -e "INFOFILE_C=/tmp/.oscam" >> $dest
echo -e "INFOFILE_D=ecm3.info" >> $dest
echo -e "INFOFILE_E=ecm4.info" >> $dest
echo -e "INFOFILE_F=ecm5.info" >> $dest
echo -e "#Expert window" >> $dest
echo -e "INFOFILE_LINES=1111111111000000" >> $dest
echo -e "#Zapp after start" >> $dest
echo -e "REZAPP=0" >> $dest
echo -e "" >> $dest
echo -e "########################################" >> $dest
echo -e "" >> $dest
echo -e "logger \00440 \00441" >> $dest
echo -e "echo \00440 \00441" >> $dest
echo -e "" >> $dest
echo -e "remove_tmp () {" >> $dest
echo -e "    rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*mbox* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam.* /tmp/*.oscam" >> $dest
echo -e "}" >> $dest 	
echo -e "" >> $dest
echo -e "case \0042\00441\0042 in" >> $dest
echo -e "  start)" >> $dest
echo -e "  remove_tmp" >> $dest
echo -e "  /usr/bin/oscam_$version -S -c /etc/tuxbox/config/oscam_1.20 &" >> $dest
echo -e "  ;;" >> $dest
echo -e "  stop)" >> $dest
echo -e "  killall -9 oscam_$version 2>/dev/null" >> $dest
echo -e "  sleep 2" >> $dest
echo -e "  remove_tmp" >> $dest
echo -e "  ;;" >> $dest
echo -e "  *)" >> $dest
echo -e "  \00440 stop" >> $dest
echo -e "  exit 0" >> $dest
echo -e "  ;;" >> $dest
echo -e "esac" >> $dest
echo -e "" >> $dest
echo -e "exit 0 " >> $dest
chmod 755 $dest
sleep 1
echo ""
echo "Pobrano Najnowszego OSCama $version"
echo ""
echo "Najnowszy OSCam Jest Gotowy Do Uruchomienia"
echo ""

exit 0
