#!/bin/sh

if test -f /media/usb/oscam_bh_config_kopia.tar.gz
then

echo "Trwa instalacja, czekaj.."
echo ""

rm -rf /etc/tuxbox/config

tar -zxf  /media/usb/oscam_bh_config_kopia.tar.gz -C / 2>/dev/null

sleep 1

echo "Restart SoftCam.."
echo ""
/var/bin/StartBhCam restart
echo ""

sleep 1
echo "Kopia została przywrócona pomyślnie.."
echo ""

sleep 2

else

echo "Kopia nie została zainstalowana, nie można znaleźć pliku z kopią oscam config"
echo ""

fi


exit 0
