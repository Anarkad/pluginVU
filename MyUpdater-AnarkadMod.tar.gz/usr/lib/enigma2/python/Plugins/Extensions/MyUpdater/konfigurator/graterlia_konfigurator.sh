#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/graterlia_configi.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/configi.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/graterlia_oscamy.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscamy.cfg

echo "Konfiguracja zakończona pomyślnie..." 

exit 0
