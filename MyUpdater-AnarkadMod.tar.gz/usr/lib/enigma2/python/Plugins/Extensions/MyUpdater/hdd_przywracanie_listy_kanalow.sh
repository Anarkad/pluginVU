#!/bin/sh

if test -f /media/hdd/lista_kanalow_kopia.tar.gz
then

echo "Trwa instalacja, czekaj.."
echo ""

rm -f /etc/enigma2/blacklist
rm -f /etc/enigma2/whitelist
rm -f /etc/enigma2/bouquets.*
rm -f /etc/enigma2/lamedb
rm -f /etc/enigma2/userbouquet.*

tar -zxf  /media/hdd/lista_kanalow_kopia.tar.gz -C / 2>/dev/null
wget -q -O /dev/null http://127.0.0.1/web/servicelistreload?mode=0 2>/dev/null

sleep 1
echo "Zainstalowano pomyślnie.."
echo ""

else

echo "Lista nie została zainstalowana, nie można znaleźć pliku z kopią listy"
echo ""

fi


exit 0
