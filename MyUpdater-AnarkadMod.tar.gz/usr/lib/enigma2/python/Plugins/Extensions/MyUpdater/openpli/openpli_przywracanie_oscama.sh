#!/bin/sh

oscam=/usr/bin
script=/etc/init.d

echo "Stop SoftCam"
/etc/init.d/softcam stop

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam
echo "Przywracanie skryptu z softcam.oscam-prev"
cp $script/softcam.oscam-prev $script/softcam.oscam.sh

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/etc/init.d/softcam start
echo "The End"
