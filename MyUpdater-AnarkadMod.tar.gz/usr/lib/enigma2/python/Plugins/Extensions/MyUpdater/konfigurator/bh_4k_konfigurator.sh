#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/bh_configi.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/configi.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/bh_oscamy.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscamy.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_bh_4k.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_bh.cfg

echo "Konfiguracja zakończona pomyślnie..." 

exit 0
