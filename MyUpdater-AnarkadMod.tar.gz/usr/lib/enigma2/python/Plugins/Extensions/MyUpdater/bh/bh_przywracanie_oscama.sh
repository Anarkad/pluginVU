#!/bin/sh

oscam=/usr/bin
script=/usr/camscript

echo "Stop SoftCam"
/var/bin/StartBhCam stop

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam
echo "Przywracanie skryptu z Ncam_Oscam.sh-prev"
cp $script/Ncam_Oscam.sh-prev $script/Ncam_Oscam.sh

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/var/bin/StartBhCam start	
echo "The End"
