#!/bin/sh

# zakaz modyfikowania skryptu

rm -rf /tmp/0b01_nc+.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/0b01_nc+.zip -q -O /tmp/0b01_nc+.zip
FILE=/tmp/0b01_nc+.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Operacja Przerwana!!! Niepoprawny plik $FILE!"
        exit 0
    else
	    echo ""
		echo "Pobrano OSCam Config"
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/0b01_nc+.zip -d /tmp/
        cd /tmp/0b01_nc+
        if [ -f oscam.conf ]; then
			rm -fR /etc/tuxbox/config/oscam_1.20/*
            mkdir -p /etc/tuxbox/config/oscam_1.20 && mv /tmp/0b01_nc+/* /etc/tuxbox/config/oscam_1.20/
			cd / && rm -rf /tmp/0b01_nc+
            rm -rf /tmp/0b01_nc+.zip
            echo ""
            echo "Wgrywanie nowego configu przebiegło poprawnie"
			echo ""
			echo "Restartuje SoftCam"
			echo ""
			/etc/.CamdReStart.sh >/dev/null 2>&1 &
		else
		    echo ""
            echo "Operacja Przerwana!!! Brak pełnego configu na UPLOAD!"
			echo ""
        fi
   fi
else
    echo ""
    echo "Operacja Przerwana!!! Brak pliku config na UPLOAD!"
	echo ""
fi