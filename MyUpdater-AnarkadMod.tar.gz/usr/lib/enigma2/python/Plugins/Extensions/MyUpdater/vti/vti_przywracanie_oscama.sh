#!/bin/sh

oscam=/usr/bin
script=/usr/script

echo "Stop SoftCam"
/etc/init.d/current_cam.sh stop

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam
echo "Przywracanie skryptu z oscam_cam.sh-prev"
cp $script/oscam_cam.sh-prev $script/oscam_cam.sh.sh

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/etc/init.d/current_cam.sh start
echo "The End"
