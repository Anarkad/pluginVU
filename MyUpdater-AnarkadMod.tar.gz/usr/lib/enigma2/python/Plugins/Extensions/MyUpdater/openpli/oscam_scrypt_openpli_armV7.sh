#!/bin/sh

OSCAM_START="/etc/init.d/softcam start";

OSCAM_STOP="/etc/init.d/softcam stop";

echo " Stop SoftCam "

$OSCAM_STOP

echo "Search new version oscam"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/armV7&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "armV7-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-armV7-webif-Distribution.tar.gz&directory=1.20_TRUNK/armV7&'
echo "Download oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
echo "Unpack tar.gz"
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Copy oscam_$version to /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam_$version
echo "Remove temp file"
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
dest="/etc/init.d/softcam.oscam_$version"
echo "* Do it file *"$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAMD_NAME=\0042OSCam $version\0042" >> $dest
echo -e "case \0042\00441\0042 in" >> $dest
echo -e "start)" >> $dest
echo -e " ulimit -s 1024" >> $dest
echo -e " /usr/bin/oscam_$version --config-dir /etc/tuxbox/config/oscam --daemon --pidfile /tmp/oscam.pid --restart 2 --utf8" >> $dest
echo -e " ;;" >> $dest
echo -e "stop)" >> $dest	
echo -e " killall -9 oscam_$version 2>/dev/null" >> $dest
echo -e " ;;" >> $dest
echo -e " restart)" >> $dest
echo -e " \00440 stop" >> $dest
echo -e " sleep 1" >> $dest
echo -e " \00440 start" >> $dest
echo -e " ;;" >> $dest
echo -e "info)" >> $dest
echo -e " echo \0042OSCam $version\0042" >> $dest
echo -e " ;;" >> $dest
echo -e "*)" >> $dest
echo -e " exit 1" >> $dest
echo -e " ;;" >> $dest
echo -e "esac" >> $dest
echo -e "exit 0 " >> $dest
chmod 755 $dest
sleep 1
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo " Start SoftCam "

$OSCAM_START

echo " The End "
