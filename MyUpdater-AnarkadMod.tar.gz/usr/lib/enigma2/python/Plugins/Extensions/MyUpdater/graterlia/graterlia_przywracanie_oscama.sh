#!/bin/sh

oscam=/usr/bin

echo "Stop SoftCam"
/etc/init.d/softcam stop

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/etc/init.d/softcam start
echo "The End"
