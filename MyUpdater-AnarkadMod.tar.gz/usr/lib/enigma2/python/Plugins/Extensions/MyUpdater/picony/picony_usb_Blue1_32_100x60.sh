#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/blue1_32_100x60.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/blue1_32_100x60.zip -q -O /tmp/blue1_32_100x60.zip
FILE=/tmp/blue1_32_100x60.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Picony zostały pobrane.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/blue1_32_100x60.zip -d /tmp/
        cd /tmp/blue1_32_100x60
        if [ -f picon_default.png ]; then
			rm -fR /media/usb/picon/*
            mkdir -p /media/usb/picon && mv /tmp/blue1_32_100x60/* /media/usb/picon/
			cd / && rm -rf /tmp/blue1_32_100x60
            rm -rf /tmp/blue1_32_100x60.zip
            echo ""
            echo "Wgrywanie nowych picon zakończono pomyślnie..."
			echo ""
		else
		    echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku picon.zip na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi