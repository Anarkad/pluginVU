#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/transparent_ciemne_32_220x132.zip

cd /tmp/
wget https://github.com/Anarkad/pluginVU/raw/master/picony/picony_ciemne.zip -q -O /tmp/picony_ciemne.zip
FILE=/tmp/picony_ciemne.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Picony zostały pobrane.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/picony_ciemne.zip -d /tmp/
        cd /tmp/picony_ciemne
        if [ -f picon_default.png ]; then
			rm -fR /media/hdd/picon/*
            mkdir -p /media/hdd/picon && mv /tmp/picony_ciemne/* /media/hdd/picon/
			cd / && rm -rf /tmp/picony_ciemne
            rm -rf /tmp/picony_ciemne.zip
            echo ""
            echo "Wgrywanie nowych picon zakończono pomyślnie..."
			echo ""
		else
		    echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku picony_ciemne.zip na GitHub! Spróbuj ponownie później..."
	echo ""
fi
