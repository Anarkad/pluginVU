#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/transparent_ciemne_32_220x132.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/transparent_ciemne_32_220x132.zip -q -O /tmp/transparent_ciemne_32_220x132.zip
FILE=/tmp/transparent_ciemne_32_220x132.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Picony zostały pobrane.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/transparent_ciemne_32_220x132.zip -d /tmp/
        cd /tmp/transparent_ciemne_32_220x132
        if [ -f picon_default.png ]; then
			rm -fR /media/hdd/picon/*
            mkdir -p /media/hdd/picon && mv /tmp/transparent_ciemne_32_220x132/* /media/hdd/picon/
			cd / && rm -rf /tmp/transparent_ciemne_32_220x132
            rm -rf /tmp/transparent_ciemne_32_220x132.zip
            echo ""
            echo "Wgrywanie nowych picon zakończono pomyślnie..."
			echo ""
		else
		    echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku picon.zip na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi