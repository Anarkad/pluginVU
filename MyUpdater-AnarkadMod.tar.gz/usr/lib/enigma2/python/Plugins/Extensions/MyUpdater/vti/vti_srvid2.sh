#!/bin/sh

wget -q -O /tmp/oscam.srvid2 http://myupdater.dyndns-ip.com/oscam.srvid2 2>/dev/null

cp /tmp/oscam.srvid2 /etc/tuxbox/config/

echo "Restart SoftCam.."
echo ""
/etc/init.d/current_cam.sh restart
echo ""

echo "Pomyślnie zaktualizowano oscam.srvid2" 

rm -rf /tmp/oscam.srvid2

exit 0
