#!/bin/sh

wget -q -O /tmp/oscam.srvid http://myupdater.dyndns-ip.com/oscam.srvid 2>/dev/null

cp /tmp/oscam.srvid /etc/tuxbox/config/oscam_1.20/
  
echo ""

echo "Aktualizacja oscam.srvid przebiegła poprawnie" 

rm -rf /tmp/oscam.srvid

echo ""
echo "Restartuje SoftCam"
echo ""
/etc/.CamdReStart.sh >/dev/null 2>&1 &

exit 0
