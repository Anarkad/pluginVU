#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę
# zakaz modyfikowania list kanałów i ich późniejsze udostępnianie
# No permission to modify this PLUGIN !!!
# protection by Sancho!!!

rm -rf /tmp/anarkadlista.zip

cd /tmp/
wget https://github.com/Anarkad/pluginVU/raw/master/lista_kanalow/anarkadlista.zip -O /tmp/anarkadlista.zip
FILE=/tmp/anarkadlista.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 500 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
        unzip -o /tmp/anarkadlista.zip -d /tmp/
        cd /tmp/anarkadlista
        if [ -f satellites.xml ]; then
            rm -rf /etc/tuxbox/satellites.xml
            mv /tmp/anarkadlista/satellites.xml /etc/tuxbox/
            cd /etc/enigma2
            rm -rf *.tv
            rm -rf *.radio
            rm -rf blacklist
            rm -rf lamedb
            mv /tmp/anarkadlista/* /etc/enigma2
			
            rm -rf /tmp/anarkadlista
            rm -rf /tmp/anarkadlista.zip
			
            wget -q -O /dev/null http://127.0.0.1/web/servicelistreload?mode=0 2>/dev/null
			echo ""
            echo "Wgrywanie nowej listy kanałów zakończono pomyślnie..."
			echo ""
        else
            echo "Błąd! brak listy! Spróbuj ponownie później..."
        fi
   fi
else
    echo "Błąd! brak pliku listy kanałów! Spróbuj ponownie później..."
fi
