#!/bin/sh

echo ""
echo "Usuwanie Picon"
echo ""

sleep 1
rm -f /media/hdd/picon/*

echo "Picony zostały usunięte"
echo ""
sleep 1

exit 0
