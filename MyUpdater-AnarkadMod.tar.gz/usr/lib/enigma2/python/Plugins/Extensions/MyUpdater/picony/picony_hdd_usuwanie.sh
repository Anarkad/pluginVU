#!/bin/sh

echo ""
echo "Usuwanie Picon"
echo ""

sleep 1
rm -f /media/hdd/picon/*
rm -f /usr/share/enigma2/picon/*

echo "Picony zostały usunięte"
echo ""
sleep 1

exit 0
