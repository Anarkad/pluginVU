#!/bin/sh

cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/openpli_configi.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/configi.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/openpli_oscamy.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscamy.cfg
cp /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/konfigurator/oscam_image_openpli_4k.cfg /usr/lib/enigma2/python/Plugins/Extensions/MyUpdater/oscam_image_openpli.cfg

echo "Konfiguracja zakończona pomyślnie..." 

exit 0
