#!/bin/sh

echo "Szukam nowego OSCama"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/armV7&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "armV7-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-armV7-webif-Distribution.tar.gz&directory=1.20_TRUNK/armV7&'
echo "Pobieranie oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Kopiowanie oscam_$version do /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam_$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
	dest="/usr/camscript/Ncam_Oscam-"$version".sh"
echo "Tworzenie Scryptu "$dest
	echo -e "#!/bin/sh" > $dest
	echo -e "" >> $dest
	echo -e "CAMNAME=\0042OScam $version\0042" >> $dest 
	echo -e "" >> $dest
	echo -e "case \0042\00441\0042 in" >> $dest
	echo -e "    start)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        /usr/bin/oscam_$version -b -r 2 -c /etc/tuxbox/config" >> $dest
	echo -e "        touch /tmp/.emu.info" >> $dest
	echo -e "        echo \0044CAMNAME > /tmp/.emu.info" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    stop)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        killall -9 oscam_$version 2>/dev/null" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    restart)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        sleep 2" >> $dest
	echo -e "        \00440 start" >> $dest
	echo -e "        exit" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    *)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        exit 0" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "esac" >> $dest
	echo -e "exit 0 " >> $dest
	chmod 755 $dest
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
exit 0