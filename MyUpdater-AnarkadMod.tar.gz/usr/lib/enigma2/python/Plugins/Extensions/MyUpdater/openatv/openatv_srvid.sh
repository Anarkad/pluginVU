#!/bin/sh

wget -q -O /tmp/oscam.srvid http://myupdater.dyndns-ip.com/oscam.srvid 2>/dev/null

cp /tmp/oscam.srvid /usr/keys/oscam_atv/

echo "Pomyślnie zaktualizowano oscam.srvid" 
echo ""

echo "Wymagany Restart OSCama!"

rm -rf /tmp/oscam.srvid

exit 0
