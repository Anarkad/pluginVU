#!/bin/sh

if test -f /media/hdd/oscam_openpli_config_kopia.tar.gz
then

echo "Trwa instalacja, czekaj.."
echo ""

echo "Stop SoftCam"
echo ""
/etc/init.d/softcam stop
echo ""

rm -rf /etc/tuxbox/config/oscam

tar -zxf  /media/hdd/oscam_openpli_config_kopia.tar.gz -C / 2>/dev/null

sleep 1

echo "Start SoftCam.."
echo ""
/etc/init.d/softcam start
echo ""

sleep 1
echo "Kopia została przywrócona pomyślnie.."
echo ""

sleep 2

else

echo "Kopia nie została zainstalowana, nie można znaleźć pliku z kopią oscam config"
echo ""

fi


exit 0
