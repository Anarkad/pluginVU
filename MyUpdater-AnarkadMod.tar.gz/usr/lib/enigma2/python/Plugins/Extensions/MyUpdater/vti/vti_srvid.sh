#!/bin/sh

wget -q -O /tmp/oscam.srvid http://myupdater.dyndns-ip.com/oscam.srvid 2>/dev/null

cp /tmp/oscam.srvid /etc/tuxbox/config/

echo "Restart SoftCam.."
echo ""
/etc/init.d/current_cam.sh restart
echo ""

echo "Pomyślnie zaktualizowano oscam.srvid" 

rm -rf /tmp/oscam.srvid

exit 0
