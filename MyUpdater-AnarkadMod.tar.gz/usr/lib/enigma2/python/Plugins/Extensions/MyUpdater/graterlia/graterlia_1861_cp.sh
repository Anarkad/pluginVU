#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/nbox_1861_cp.zip

cd /tmp/
wget http://myupdater.dyndns-ip.com/nbox_1861_cp.zip -q -O /tmp/nbox_1861_cp.zip
FILE=/tmp/nbox_1861_cp.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Config został pobrany.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/nbox_1861_cp.zip -d /tmp/
        cd /tmp/nbox_1861_cp
        if [ -f oscam.conf ]; then
			rm -fR /etc/oscam/*
            mkdir -p /etc/oscam && mv /tmp/nbox_1861_cp/* /etc/oscam/
			cd / && rm -rf /tmp/nbox_1861_cp
            rm -rf /tmp/nbox_1861_cp.zip
            echo ""
            echo "Wgrywanie nowego configu zakończono pomyślnie..."
			echo ""
			echo "Restrat SoftCam"
			echo ""
			/etc/init.d/softcam restart
		else
		    echo ""
            echo "Błąd! brak pełnego configu! Spróbuj ponownie później..."
			echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku config na UPLOAD! Spróbuj ponownie później..."
	echo ""
fi