#!/bin/sh

oscam=/var/bin
script=/var/bin

echo "Stop SoftCam"
/var/bin/softcam stop

echo "Przywracanie oscama z oscam-prev"
cp $oscam/oscam-prev  $oscam/oscam
echo "Przywracanie skryptu z softcam.oscam_sci0-prev"
cp $script/softcam.oscam_sci0-prev $script/softcam.oscam_sci0.sh

echo "Pomyślnie Przywrócono OSCama Do Poprzedniej Zapisanej Wersji"
echo "Start SoftCam"
/var/bin/softcam start
echo "The End"
