#!/bin/sh

echo "Tworzenie kopii zapasowej listy kanałów, czekaj.."
echo ""

mkdir -p /media/usb/
sleep 1
tar -czf /media/usb/lista_kanalow_kopia.tar.gz /etc/tuxbox/satellites.xml /etc/enigma2/lamedb /etc/enigma2/blacklist /etc/enigma2/whitelist /etc/enigma2/bouquets.* /etc/enigma2/userbouquet.* 2>/dev/null

if test -f /media/usb/lista_kanalow_kopia.tar.gz
then

echo "Kopia została utworzona pomyślnie.."
echo ""
sleep 1
echo "Lokalizacja pliku to: /media/usb/lista_kanalow_kopia.tar.gz"
echo ""


else

echo "Wystapił nieoczekiwany błąd - Kopia nie została utworzona.."
echo ""

fi


exit 0
