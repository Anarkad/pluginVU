#!/bin/sh

if test -f /media/usb/oscam_openspa_config_kopia.tar.gz
then

echo "Trwa instalacja, czekaj.."
echo ""

rm -rf /etc/tuxbox/config/oscam_1.20

tar -zxf  /media/usb/oscam_openspa_config_kopia.tar.gz -C / 2>/dev/null

sleep 1
echo "Kopia configu została przywrócona poprawnie"
echo ""
echo "Restartuje SoftCam"
echo ""
/etc/.CamdReStart.sh >/dev/null 2>&1 &

else

echo "Operacja Przerwana!!! Brak pliku oscam config na USB"
echo ""

fi

exit 0
