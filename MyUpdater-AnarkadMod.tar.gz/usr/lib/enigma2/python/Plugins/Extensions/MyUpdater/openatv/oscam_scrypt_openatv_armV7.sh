#!/bin/sh

echo "Search new version oscam"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/armV7&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "armV7-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-armV7-webif-Distribution.tar.gz&directory=1.20_TRUNK/armV7&'
echo "Download oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
echo "Unpack tar.gz"
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Copy oscam_$version to /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam_$version
echo "Remove temp file"
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
	dest="/etc/oscam_"$version".emu"
	echo -e "emuname = OSCam $version" > $dest 
	echo -e "binname = oscam_$version" >> $dest
	echo -e "startcam = /usr/bin/oscam_$version -b -r 2 -c /usr/keys/oscam_atv" >> $dest
	echo -e "stopcam = killall -9 oscam_$version 2>/dev/null" >> $dest
	chmod 755 $dest
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo "The End"
