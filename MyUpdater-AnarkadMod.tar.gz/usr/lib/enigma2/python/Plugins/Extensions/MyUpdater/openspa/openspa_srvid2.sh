#!/bin/sh

wget -q -O /tmp/oscam.srvid2 http://myupdater.dyndns-ip.com/oscam.srvid2 2>/dev/null

cp /tmp/oscam.srvid2 /etc/tuxbox/config/oscam_1.20/

echo ""

echo "Aktualizacja oscam.srvid2 przebiegła poprawnie" 

rm -rf /tmp/oscam.srvid2

echo ""
echo "Restartuje SoftCam"
echo ""
/etc/.CamdReStart.sh >/dev/null 2>&1 &

exit 0
