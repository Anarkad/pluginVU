#!/bin/sh

if test -f /media/hdd/oscam_atv_config_kopia.tar.gz
then

echo "Trwa instalacja, czekaj.."
echo ""

rm -rf /usr/keys/oscam_atv

tar -zxf  /media/hdd/oscam_atv_config_kopia.tar.gz -C / 2>/dev/null

sleep 1

echo ""

sleep 1
echo "Kopia została przywrócona pomyślnie.."
echo ""

echo "Wymagany Restart OSCama!!"
echo ""

sleep 2

else

echo "Kopia nie została zainstalowana, nie można znaleźć pliku z kopią oscam config"
echo ""

fi


exit 0
