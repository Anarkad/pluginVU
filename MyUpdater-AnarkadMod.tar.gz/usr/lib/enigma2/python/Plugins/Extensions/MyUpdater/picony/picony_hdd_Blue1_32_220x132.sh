#!/bin/sh

# zakaz modyfikowania skryptu na własną rękę

rm -rf /tmp/picony_blue.zip

cd /tmp/
wget https://github.com/Anarkad/pluginVU/raw/master/picony/picony_blue.zip -q -O /tmp/picony_blue.zip
FILE=/tmp/picony_blue.zip

if [ -e $FILE ]; then
    size=`ls -l $FILE | sed -e 's/  */ /g' | cut -d' ' -f5`
    if [ $size -le 900 ]; then
        echo "Nieprawidłowy plik $FILE! Spróbuj ponownie później..."
        exit 0
    else
	    echo ""
		echo "Picony zostały pobrane.."
        echo ""
        sleep 1
        echo "Trwa instalacja, czekaj.."
        echo ""
        unzip -o /tmp/picony_blue -d /tmp/
        cd /tmp/picony_blue
        if [ -f picon_default.png ]; then
			rm -fR /usr/share/enigma2/picon/*
            mkdir -p /usr/share/enigma2/picon && mv /tmp/picony_blue/* /usr/share/enigma2/picon/
			cd / && rm -rf /tmp/picony_blue
            rm -rf /tmp/picony_blue.zip
            echo ""
            echo "Wgrywanie nowych picon zakończono pomyślnie..."
			echo ""
		else
		    echo ""
        fi
   fi
else
    echo ""
    echo "Błąd! brak pliku picony_blue.zip na GitHub! Spróbuj ponownie później..."
	echo ""
fi
