#!/bin/sh

oscam=/usr/bin
script=/usr/script

echo "Stop SoftCam"
/etc/init.d/current_cam.sh stop

echo ""
echo "Kopia zapasowa aktualnej wersji oscam jako oscam-prev"
cp $oscam/oscam $oscam/oscam-prev
echo "Kopia zapasowa skryptu jako oscam_cam.sh-prev"
cp $script/oscam_cam.sh $script/oscam_cam.sh-prev
echo ""

echo "Search new version oscam"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-tuxbox-oe2.0&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 125 "archives" | grep "mips-tuxbox-oe2.0-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-mips-tuxbox-oe2.0-webif-Distribution.tar.gz&directory=1.20_TRUNK/mips-tuxbox-oe2.0&'
echo "Download oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
echo "Unpack tar.gz"
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Copy oscam_$version to /usr/bin"
	cp -rf /tmp/oscam /usr/bin/oscam
echo "Remove temp file"
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
	dest="/usr/script/oscam_cam.sh"
echo "Do it file "$dest
	echo -e "#!/bin/sh" > $dest
	echo -e "" >> $dest
	echo -e "CAMNAME=\0042OScam\0042" >> $dest 
	echo -e "" >> $dest
	echo -e "case \0042\00441\0042 in" >> $dest
	echo -e "    start)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        /usr/bin/oscam -b -r 2 -c /etc/tuxbox/config" >> $dest
	echo -e "        touch /tmp/.emu.info" >> $dest
	echo -e "        echo \0044CAMNAME > /tmp/.emu.info" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    stop)" >> $dest
	echo -e "        echo \0042[SCRIPT] \00441: \0044CAMNAME\0042" >> $dest
	echo -e "        killall -9 oscam 2>/dev/null" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    restart)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        sleep 2" >> $dest
	echo -e "        \00440 start" >> $dest
	echo -e "        exit" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "    *)" >> $dest
	echo -e "        \00440 stop" >> $dest
	echo -e "        exit 0" >> $dest
	echo -e "    ;;" >> $dest
	echo -e "esac" >> $dest
	echo -e "exit 0 " >> $dest
	chmod 755 $dest
sleep 1
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo " Start SoftCam "
/etc/init.d/current_cam.sh start
echo "The End"
