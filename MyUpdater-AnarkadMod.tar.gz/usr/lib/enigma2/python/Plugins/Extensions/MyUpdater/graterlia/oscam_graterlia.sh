#!/bin/sh

oscam=/usr/bin

echo "Stop SoftCam"
	    /etc/init.d/softcam stop
	    echo "Kopia zapasowa aktualnej wersji oscam jako oscam-prev"
	    cp $oscam/oscam $oscam/oscam-prev


echo "Search new version oscam"
	www="http://download.oscam.cc/index.php?&direction=0&order=mod&directory=1.20_TRUNK/sh4-amino&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "sh4-amino-webif-Distribution.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://download.oscam.cc/index.php?action=downloadfile&filename=oscam-svn'$version'-sh4-amino-webif-Distribution.tar.gz&directory=1.20_TRUNK/sh4-amino&'
echo "Download oscam_$version"
	wget $LINK -q -O /tmp/plik.tar.gz
echo "Unpack tar.gz"
	tar -xzf /tmp/plik.tar.gz -C /tmp
echo "Copy oscam_$version to /usr/bin"
	cp -rf /tmp/oscam /var/bin/oscam
echo "Remove temp file"
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/plik.tar.gz ] && rm /tmp/plik.tar.gz 
	[ -e /tmp/oscam ] && rm /tmp/oscam 
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
sleep 1
echo ""
echo "Zaktualizowano OSCama Do Wersji $version"
echo ""
echo " Start SoftCam "
/etc/init.d/softcam start
echo "The End"
