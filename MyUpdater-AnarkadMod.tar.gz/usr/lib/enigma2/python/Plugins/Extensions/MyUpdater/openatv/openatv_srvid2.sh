#!/bin/sh

wget -q -O /tmp/oscam.srvid2 http://myupdater.dyndns-ip.com/oscam.srvid2 2>/dev/null

cp /tmp/oscam.srvid2 /usr/keys/oscam_atv/

echo "Pomyślnie zaktualizowano oscam.srvid2" 
echo ""

echo "Wymagany Restart OSCama!"

rm -rf /tmp/oscam.srvid2

exit 0
